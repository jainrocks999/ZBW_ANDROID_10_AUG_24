import React from 'react';
import {
  View,
  Text,
  Dimensions,
  ScrollView,
  ImageBackground,
} from 'react-native';
import Image from 'react-native-scalable-image';
import Header from '../../../components/CustomHeader';
import {useNavigation} from '@react-navigation/native';

const Chauviharcode = () => {
  const navigation = useNavigation();

  return (
    <ImageBackground
      source={require('../../../assets/Logo/background.png')}
      style={{flex: 1}}>
      <Header
        title={'My QR'}
        onPress={() => navigation.goBack()}
        onPress2={() => navigation.navigate('Notification')}
      />

      <View
        style={{
          alignItems: 'center',
          justifyContent: 'flex-start',
          position: 'absolute',
          top: '40%',
          left: 0,
          right: 0,
          bottom: 0,
        }}>
        {true ? (
          <Image
            source={require('../../../assets/LocalImage/ChauviharQR.jpg')}
          />
        ) : null}
      </View>
    </ImageBackground>
  );
};
export default Chauviharcode;
