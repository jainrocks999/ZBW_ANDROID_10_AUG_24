import {
  View,
  Text,
  ImageBackground,
  StyleSheet,
  FlatList,
  TouchableOpacity,
  Alert,
} from 'react-native';
import React, {useState} from 'react';
import Header from '../../../components/CustomHeader';
import {useNavigation} from '@react-navigation/native';
import RadioGroup from '../../../components/Radio/RadioComponent';
import ArrowDown from '../../../assets/Icon/ArrowDown.svg';
import {Menu, MenuItem, MenuDivider} from 'react-native-material-menu';
import {useDispatch} from 'react-redux';

const ChauviharEventdetails = () => {
  const dispatch = useDispatch();
  const [visible, setVisible] = useState(-1);
  const hideMenu = () => setVisible(-1);
  const showMenu = index => setVisible(index);
  const [selectedOptions, setSelectedOptions] = useState({});
  const [selectedtime, setSelectedtime] = useState({});

  const handleRadioPress = (itemIndex, selectedId) => {
    setSelectedOptions(prevState => ({
      ...prevState,
      [itemIndex]: selectedId,
    }));
    setSelectedtime(prev => ({
      ...prev,
      [itemIndex]: '',
    }));
  };

  const handleMenuPress = (itemIndex, selected) => {
    setSelectedtime(prev => ({
      ...prev,
      [itemIndex]: selected,
    }));
    setVisible(-1);
  };

  const renderRow = ({item, index}) => (
    <View style={styles.row}>
      <View style={styles.cell}>
        <Text
          style={{
            color: '#000000',
            fontFamily: 'Montserrat-SemiBold',
            fontSize: 14,
          }}>
          {item.e_date}
        </Text>
      </View>
      <View style={styles.cell}>
        <RadioGroup
          containerStyle={{
            flexDirection: 'column',
            width: '100%',
            justifyContent: 'space-between',
          }}
          labelStyle={{
            fontSize: 12,
            fontFamily: 'Montserrat-SemiBold',
            color: '#000000',
            width: 74,
          }}
          radioButtons={item.option1}
          onPress={id => {
            handleRadioPress(index, id);
          }}
          selectedId={selectedOptions[index]}
        />
      </View>
      <View style={styles.cell}>
        {selectedOptions[index] && selectedOptions[index] !== '1' ? (
          <Menu
            visible={index == visible}
            anchor={
              <TouchableOpacity
                onPress={() => {
                  showMenu(index);
                }}
                style={{
                  padding: 5,
                  flexDirection: 'row',
                  alignItems: 'center',
                  justifyContent: 'center',
                }}>
                {selectedtime[index] ? (
                  <Text
                    style={{
                      fontSize: 13,
                      fontFamily: 'Montserrat-SemiBold',
                      color: 'black',
                    }}>
                    {selectedtime[index]}
                  </Text>
                ) : (
                  <View
                    style={{
                      padding: 5,
                      backgroundColor: '#fff',
                      flexDirection: 'row',
                      borderRadius: 6,
                      elevation: 5,
                      paddingHorizontal: 10,
                    }}>
                    <Text
                      style={{
                        fontSize: 13,
                        fontFamily: 'Montserrat-SemiBold',
                        color: 'black',
                      }}>
                      {'Select '}
                    </Text>
                    <View style={{marginTop: 5, marginLeft: 5}}>
                      <ArrowDown height={10} width={10} color={'red'} />
                    </View>
                  </View>
                )}
              </TouchableOpacity>
            }
            onRequestClose={hideMenu}>
            {Object.keys(item.option2)
              .filter(item =>
                selectedOptions[index] != '-1' ? item : item != 'Both',
              )
              .map(item => {
                return (
                  <>
                    <MenuItem
                      textStyle={{
                        fontSize: 12,
                        fontFamily: 'Montserrat-Medium',
                        color: '#000000',
                      }}
                      onPress={() => handleMenuPress(index, item)}>
                      {item}
                    </MenuItem>
                    <MenuDivider />
                  </>
                );
              })}
          </Menu>
        ) : (
          <Text>{'-'}</Text>
        )}
      </View>
    </View>
  );

  const renderHeader = () => (
    <View style={styles.header}>
      <View style={styles.headerCell}>
        <Text style={styles.headerText}>Date</Text>
      </View>
      <View style={styles.headerCell}>
        <Text style={styles.headerText}> {''}</Text>
      </View>
      <View style={styles.headerCell}>
        <Text style={styles.headerText}>Slots</Text>
      </View>
    </View>
  );

  // const handleSubmit = () => {
  //   const mergedData = chauvhiarDates.map((item, index) => ({
  //     e_date: item.e_date,
  //     selectedOption: selectedOptions[index] ?? '',
  //     selectedTime: selectedtime[index] ?? '',
  //   }));
  //   dispatch({
  //     type: 'setHome',
  //   });
  //   const unSelectedDates = mergedData
  //     .filter(item => item.selectedOption == '')
  //     .map(item => item.e_date);
  //   if (unSelectedDates.length === mergedData.length) {
  //     Alert.alert('Alert', 'have to select at least 1 day');
  //     return;
  //   }
  //   const selecteDates = mergedData.filter(
  //     item => item.selectedOption != '' && item.selectedOption != '1',
  //   );
  //   const unsilectedtime = selecteDates
  //     .filter(item => item.selectedOption != '1' && item.selectedTime == '')
  //     .map(item => item.e_date);
  //   if (unsilectedtime.length > 0) {
  //     Alert.alert(
  //       'Alert',
  //       unsilectedtime.length > 1
  //         ? `select the slot for these dates ${unsilectedtime.join(',')}`
  //         : `select the slot for these date ${unsilectedtime[0]}`,
  //     );
  //     return;
  //   }
  //   if (unSelectedDates.length > 0) {
  //     Alert.alert(
  //       'Alert',
  //       unSelectedDates.length > 1
  //         ? `Are you sure to not attend the event on these days ${unSelectedDates.join(
  //             ',',
  //           )}?? `
  //         : `Are you sure to not attend the event on these day ${unSelectedDates.join(
  //             ',',
  //           )}?? `,
  //     );
  //   }

  //   console.log('Merged Data:', JSON.stringify(mergedData));
  // };
  const handleSubmit = () => {
    const mergedData = chauvhiarDates.map((item, index) => ({
      e_date: item.e_date,
      selectedOption: selectedOptions[index] ?? '',
      selectedTime: selectedtime[index] ?? '',
    }));

    const unselectedDates = mergedData
      .filter(item => !item.selectedOption)
      .map(item => item.e_date);
    if (unselectedDates.length === mergedData.length) {
      Alert.alert('Alert', 'You must select at least one day.');
      return;
    }

    const selectedDates = mergedData.filter(
      item => item.selectedOption && item.selectedOption !== '1',
    );
    const datesWithoutTime = selectedDates
      .filter(item => !item.selectedTime)
      .map(item => item.e_date);
    if (datesWithoutTime.length > 0) {
      Alert.alert(
        'Alert',
        datesWithoutTime.length > 1
          ? `Please select a slot for these dates: ${datesWithoutTime.join(
              ', ',
            )}`
          : `Please select a slot for this date: ${datesWithoutTime[0]}`,
      );
      return;
    }

    if (unselectedDates.length > 0) {
      Alert.alert(
        'Alert',
        unselectedDates.length > 1
          ? `Are you sure you don't want to attend the event on these days: ${unselectedDates.join(
              ', ',
            )}?`
          : `Are you sure you don't want to attend the event on this day: ${unselectedDates[0]}?`,
        [
          {
            text: 'Cancel',
            style: 'cancel',
          },
          {
            text: 'OK',
            onPress: () => {
              navigation.reset({index: 0, routes: [{name: 'Home'}]});
              console.log('User confirmed unselected dates.');
            },
          },
        ],
      );
      return;
    }
    dispatch({
      type: 'setHome',
    });
    navigation.reset({index: 0, routes: [{name: 'Home'}]});
    console.log('Merged Data:', JSON.stringify(mergedData));
  };

  const navigation = useNavigation();
  return (
    <ImageBackground
      source={require('../../../assets/Logo/background.png')}
      style={styles.container}>
      <Header
        title={'Chauvihar Event'}
        onPress={() => navigation.goBack()}
        onPress2={() => navigation.navigate('Notification')}
      />
      {renderHeader()}
      <FlatList
        data={chauvhiarDates}
        contentContainerStyle={{paddingBottom: 10}}
        renderItem={renderRow}
      />
      <TouchableOpacity onPress={handleSubmit} style={styles.touch1}>
        <Text style={styles.text}>Submit</Text>
      </TouchableOpacity>
    </ImageBackground>
  );
};

export default ChauviharEventdetails;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#FFFFFF',
  },
  header: {
    flexDirection: 'row',
    borderBottomWidth: 0.5,
    borderColor: '#000',
  },
  headerCell: {
    flex: 1,
    padding: 10,
    justifyContent: 'center',
    alignItems: 'center',
    borderRightWidth: 1,
    borderColor: '#000',
  },
  headerText: {
    fontFamily: 'Montserrat-Bold',
    fontSize: 14,
    color: 'black',
  },
  table: {
    borderWidth: 0.5,
    borderColor: '#000',
    margin: 10,
  },
  row: {
    flexDirection: 'row',
  },
  cell: {
    flex: 1,
    borderWidth: 0.5,
    borderColor: '#000',
    padding: 10,
    justifyContent: 'center',
    alignItems: 'center',
  },
  touch1: {
    height: 43,
    width: 130,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#FCDA64',
    borderRadius: 20,
    alignSelf: 'center',
    marginVertical: 10,
  },
  text: {
    fontFamily: 'Montserrat-Medium',
    color: '#000000',
    fontSize: 14,
  },
});

export const chauvhiarDates = [
  {
    e_date: '31-08-2024',
    option1: [
      {id: '1', label: 'Ekasna', value: 'Ekasna'},
      {id: '2', label: 'Biyasna', value: 'Biyasna'},
      {id: '3', label: 'Chauvihar', value: 'Chauvihar'},
    ],
    option2: {
      Morning: 'Morning',
      Evening: 'Evening',
      Both: 'Both',
    },
  },
  {
    e_date: '01-09-2024',
    option1: [
      {id: '1', label: 'Ekasna', value: 'Ekasna'},
      {id: '2', label: 'Biyasna', value: 'Biyasna'},
      {id: '3', label: 'Chauvihar', value: 'Chauvihar'},
    ],
    option2: {
      Morning: 'Morning',
      Evening: 'Evening',
      Both: 'Both',
    },
  },
  {
    e_date: '02-09-2024',
    option1: [
      {id: '1', label: 'Ekasna', value: 'Ekasna'},
      {id: '2', label: 'Biyasna', value: 'Biyasna'},
      {id: '3', label: 'Chauvihar', value: 'Chauvihar'},
    ],
    option2: {
      Morning: 'Morning',
      Evening: 'Evening',
      Both: 'Both',
    },
  },
  {
    e_date: '03-09-2024',
    option1: [
      {id: '1', label: 'Ekasna', value: 'Ekasna'},
      {id: '2', label: 'Biyasna', value: 'Biyasna'},
      {id: '3', label: 'Chauvihar', value: 'Chauvihar'},
    ],
    option2: {
      Morning: 'Morning',
      Evening: 'Evening',
      Both: 'Both',
    },
  },
  {
    e_date: '04-09-2024',
    option1: [
      {id: '1', label: 'Ekasna', value: 'Ekasna'},
      {id: '2', label: 'Biyasna', value: 'Biyasna'},
      {id: '3', label: 'Chauvihar', value: 'Chauvihar'},
    ],
    option2: {
      Morning: 'Morning',
      Evening: 'Evening',
      Both: 'Both',
    },
  },
  {
    e_date: '05-09-2024',
    option1: [
      {id: '1', label: 'Ekasna', value: 'Ekasna'},
      {id: '2', label: 'Biyasna', value: 'Biyasna'},
      {id: '3', label: 'Chauvihar', value: 'Chauvihar'},
    ],
    option2: {
      Morning: 'Morning',
      Evening: 'Evening',
      Both: 'Both',
    },
  },
  {
    e_date: '06-09-2024',
    option1: [
      {id: '1', label: 'Ekasna', value: 'Ekasna'},
      {id: '2', label: 'Biyasna', value: 'Biyasna'},
      {id: '3', label: 'Chauvihar', value: 'Chauvihar'},
    ],
    option2: {
      Morning: 'Morning',
      Evening: 'Evening',
      Both: 'Both',
    },
  },
];
