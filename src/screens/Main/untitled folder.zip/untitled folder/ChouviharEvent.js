import {
  StyleSheet,
  Text,
  View,
  ImageBackground,
  TouchableOpacity,
  Dimensions,
} from 'react-native';
import React from 'react';
import Header from '../../../components/CustomHeader';
import {useNavigation} from '@react-navigation/native';
import AsyncStorage from '@react-native-async-storage/async-storage';
const {width} = Dimensions.get('window');
const ChouviharEvent = () => {
  const navigation = useNavigation();
  return (
    <ImageBackground
      source={require('../../../assets/Logo/background.png')}
      style={styles.container}>
      <Header
        title={'Chauvihar'}
        onPress={() => navigation.goBack()}
        onPress2={() => navigation.navigate('Notification')}
      />
      <View
        style={{
          flex: 1,
          alignItems: 'center',
          justifyContent: 'center',
        }}>
        <View style={{marginTop: -45}}>
          <TouchableOpacity
            onPress={async () => {
              const showMember = await AsyncStorage.getItem('Member');
              if (showMember == 'Not a member') {
                navigation.navigate('MemeberRegistration');
              } else {
                // navigation.navigate('ChauviharEventList');
                navigation.navigate('MemeberRegistration');
              }
            }}
            style={styles.touch1}>
            <Text style={styles.text}>{'Registration'}</Text>
          </TouchableOpacity>
          <TouchableOpacity
            onPress={() => {
              navigation.navigate('ChauViharMenuDates');
            }}
            style={styles.touch1}>
            <Text style={styles.text}>{'Menu'}</Text>
          </TouchableOpacity>
          <TouchableOpacity
            onPress={() => navigation.navigate('Chauviharcode')}
            style={styles.touch1}>
            <Text style={styles.text}>{'My QR'}</Text>
          </TouchableOpacity>
        </View>
      </View>
    </ImageBackground>
  );
};

export default ChouviharEvent;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#FFFFFF',
  },
  touch1: {
    height: 43,
    width: width * 0.75,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#FCDA64',
    borderRadius: 20,
    alignSelf: 'center',
    marginVertical: 10,
    marginTop: 20,
  },
  text: {
    fontFamily: 'Montserrat-Medium',
    color: '#000000',
    fontSize: 14,
  },
});
