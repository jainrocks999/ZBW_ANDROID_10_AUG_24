import React from 'react';
import {StyleSheet, FlatList, View, Image} from 'react-native';

const List = () => {
  return (
    <FlatList
      data={data}
      nestedScrollEnabled={true}
      contentContainerStyle={styles.contentContainer}
      keyExtractor={(_, index) => index.toString()}
      renderItem={({item}) => (
        <View style={styles.itemContainer}>
          <Image
            resizeMode="stretch"
            source={item.image}
            style={styles.image}
          />
        </View>
      )}
    />
  );
};

const data = [
  {image: require('../../../assets/Food/Jain-foods-list.png')},
  {image: require('../../../assets/Food/Jain-foods-list.png')},
  {image: require('../../../assets/Food/Jain-foods-list.png')},
  {image: require('../../../assets/Food/Jain-foods-list.png')},
  {image: require('../../../assets/Food/Jain-foods-list.png')},
  {image: require('../../../assets/Food/Jain-foods-list.png')},
];

const styles = StyleSheet.create({
  contentContainer: {
    paddingHorizontal: 25,
  },
  itemContainer: {
    width: '90%',
    borderWidth: 1,
    borderColor: '#FCDA64',
    borderRadius: 10,
    shadowColor: '#fff',
    shadowOpacity: 0.26,
    shadowOffset: {width: 0, height: 2},
    shadowRadius: 20,
    elevation: 5,
    overflow: 'hidden',
    height: 250,
    marginTop: 25,
    alignSelf: 'center',
  },
  image: {
    height: '100%',
    width: '100%',
  },
});

export default List;
